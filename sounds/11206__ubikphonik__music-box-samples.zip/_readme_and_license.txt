Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - UbikPhonik ( https://freesound.org/people/UbikPhonik/ )

You can find this pack online at: https://freesound.org/people/UbikPhonik/packs/11206/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 177954__ubikphonik__g1.aiff
    * url: https://freesound.org/s/177954/
    * license: Attribution
  * 177953__ubikphonik__g2.aiff
    * url: https://freesound.org/s/177953/
    * license: Attribution
  * 177952__ubikphonik__f2.aiff
    * url: https://freesound.org/s/177952/
    * license: Attribution
  * 177951__ubikphonik__e2.aiff
    * url: https://freesound.org/s/177951/
    * license: Attribution
  * 177950__ubikphonik__f1.aiff
    * url: https://freesound.org/s/177950/
    * license: Attribution
  * 177949__ubikphonik__d2.aiff
    * url: https://freesound.org/s/177949/
    * license: Attribution
  * 177948__ubikphonik__e1.aiff
    * url: https://freesound.org/s/177948/
    * license: Attribution
  * 177947__ubikphonik__c1.aiff
    * url: https://freesound.org/s/177947/
    * license: Attribution
  * 177946__ubikphonik__c2.aiff
    * url: https://freesound.org/s/177946/
    * license: Attribution
  * 177945__ubikphonik__c3.aiff
    * url: https://freesound.org/s/177945/
    * license: Attribution
  * 177944__ubikphonik__d1.aiff
    * url: https://freesound.org/s/177944/
    * license: Attribution
  * 177943__ubikphonik__a1.aiff
    * url: https://freesound.org/s/177943/
    * license: Attribution
  * 177942__ubikphonik__a2.aiff
    * url: https://freesound.org/s/177942/
    * license: Attribution
  * 177941__ubikphonik__b1.aiff
    * url: https://freesound.org/s/177941/
    * license: Attribution
  * 177940__ubikphonik__b2.aiff
    * url: https://freesound.org/s/177940/
    * license: Attribution


